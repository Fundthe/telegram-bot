from replit import db
import json

print("📊 USERS:")
print(json.dumps(db.get("users", {}), indent=2, ensure_ascii=False))

print("\n📦 MODULE STATS:")
print(json.dumps(db.get("modules", {}), indent=2, ensure_ascii=False))

print("\n🔁 TOTAL RUNS:", db.get("total_runs", 0))