def calculate_simple(rate, hours):
  periods = 8760 / hours
  return rate * periods