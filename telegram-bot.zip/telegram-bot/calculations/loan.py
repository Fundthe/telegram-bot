def calculate_health_factor(deposit_amount, deposit_price, borrow_amount, borrow_price, liq_threshold, borrow_factor=0.9):
  deposit_value = deposit_amount * deposit_price
  borrow_value = borrow_amount * borrow_price

  if deposit_value == 0 or liq_threshold == 0:
      return {
          "health_factor": 0,
          "risk_factor_pct": 0,
          "reserve_pct": 0,
          "deposit_value": deposit_value,
          "borrow_value": borrow_value
      }

  hf = (deposit_value * (liq_threshold / 100)) / borrow_value
  risk = (borrow_value / (deposit_value * (liq_threshold / 100))) * 100
  reserve = ((hf - 1) / 1) * 100

  return {
      "health_factor": hf,
      "risk_factor_pct": risk,
      "reserve_pct": reserve,
      "deposit_value": deposit_value,
      "borrow_value": borrow_value
  }