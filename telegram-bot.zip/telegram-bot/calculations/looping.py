def calculate_looping_table(tokens, ltv, supply_rate, borrow_rate):
  rounds = []
  deposit = tokens
  total_borrow = 0

  for i in range(1, 11):
      borrow = deposit * ltv
      total_borrow += borrow
      deposit += borrow
      net_apy = (deposit * supply_rate - total_borrow * borrow_rate) / tokens
      rounds.append({
          'round': i,
          'deposit': deposit,
          'borrow': borrow,
          'total_borrow': total_borrow,
          'apy': net_apy
      })

  return rounds

def calculate_apr(roi: float, days: int) -> float:
    try:
        if not days or days <= 0:
            return 0.0
        base = 1 + roi / 100
        if base <= 0:
            return -100.0  # если убыток сильный — APR не может быть > -100%
        apr = (base ** (365 / days) - 1) * 100
        return apr
    except Exception:
        return 0.0

def calculate_looping_advanced(
    deposit_token, deposit_amount, deposit_price, deposit_rate,
    borrow_token, borrow_amount, borrow_price, borrow_rate,
    ltv_target, ltv_liquidation,
    wrapper_bonus_pct=None,
    borrow_wrapper_bonus_pct=None,
    days=None,
    borrow_factor=0.9
):
    if ltv_target >= ltv_liquidation:
        raise ValueError("Целевой LTV не может быть выше или равен ликвидационному!")

    results = []
    loop = 0
    max_loops = 10

    total_supply = deposit_amount
    total_borrow = 0

    supply_usd = total_supply * deposit_price
    borrow_usd = borrow_amount * borrow_price

    liquidation = False

    while loop < max_loops:
        loop += 1

        max_total_borrow = total_supply * (ltv_target / 100)
        available_borrow = max_total_borrow - total_borrow

        if available_borrow <= 0:
            break  # дальше брать нельзя — иначе превысим LTV

        borrow_tokens = available_borrow / borrow_price

        total_borrow += borrow_tokens  # <--- ЭТО важно
        total_supply += borrow_tokens  # <--- И ЭТО тоже

        supply_usd = total_supply * deposit_price
        borrow_usd = total_borrow * borrow_price

        net_equity = supply_usd - borrow_usd
        ltv_now = (borrow_usd / supply_usd) * 100 if supply_usd else 0

        try:
            hf = (supply_usd * (ltv_liquidation / 100)) / (borrow_usd * borrow_factor)
        except ZeroDivisionError:
            hf = float('inf')

        try:
            risk = 1 / hf
        except ZeroDivisionError:
            risk = float('inf')

        reserve_pct = (hf - 1) * 100 if hf > 1 else (1 - hf) * -100

        if ltv_now >= ltv_liquidation or hf < 1:
            liquidation = True
            break

        supply_income = supply_usd * (deposit_rate / 100)
        borrow_cost = borrow_usd * (borrow_rate / 100)

        if borrow_wrapper_bonus_pct:
            borrow_cost *= (1 - borrow_wrapper_bonus_pct / 100)

        try:
            net_apy = ((supply_income - borrow_cost) / net_equity) * 100
        except ZeroDivisionError:
            net_apy = 0

        # 🔻 Критическая цена залога (если он падает)
        try:
            price_collateral_liq = (borrow_usd * borrow_factor) / (ltv_liquidation / 100) / total_supply
        except ZeroDivisionError:
            price_collateral_liq = 0

        # 🔺 Критическая цена долга (если она растёт)
        try:
            price_debt_liq = (supply_usd * (ltv_liquidation / 100)) / total_borrow / borrow_factor
        except ZeroDivisionError:
            price_debt_liq = 0

        results.append({
            "loop": loop,
            "deposit_tokens": total_supply,
            "borrow_tokens": total_borrow,
            "deposit_usd": supply_usd,
            "borrow_usd": borrow_usd,
            "ltv": ltv_now,
            "net_apy": net_apy,
            "hf": hf,
            "risk": risk * 100,
            "reserve_pct": reserve_pct,
            "price_collateral_liq": price_collateral_liq,
            "price_debt_liq": price_debt_liq
        })

    wrapper_usd = 0
    borrow_wrapper_usd = 0

    if wrapper_bonus_pct:
        wrapper_usd = total_supply * deposit_price * (wrapper_bonus_pct / 100)

    if borrow_wrapper_bonus_pct:
        borrow_wrapper_usd = total_borrow * borrow_price * (borrow_wrapper_bonus_pct / 100)

    return {
        "loops": results,
        "deposit_token": deposit_token,
        "borrow_token": borrow_token,
        "deposit_price": deposit_price,
        "borrow_price": borrow_price,
        "initial_deposit": deposit_amount,
        "initial_borrow": borrow_amount,
        "final_deposit": total_supply,
        "final_borrow": total_borrow,
        "wrapper_bonus": wrapper_usd,
        "borrow_wrapper_bonus": borrow_wrapper_usd,
        "liquidated": liquidation
    }

def format_looping_result(data):
    rows = data["loops"]
    deposit_token = data["deposit_token"]
    borrow_token = data["borrow_token"]
    deposit_price = data["deposit_price"]
    borrow_price = data["borrow_price"]
    wrapper = data.get("wrapper_bonus", 0)
    borrow_wrapper = data.get("borrow_wrapper_bonus", 0)
    liquidated = data.get("liquidated", False)

    def emoji(pct): return "🟢" if pct > 0 else "🔴" if pct < 0 else "⚪️"
    def hf_emoji(hf): return "🟢" if hf > 1.5 else "🟡" if hf > 1 else "🔴"
    def draw_bar(p):
        filled = int(min(max(p / 100, 0), 1) * 20)
        return "▮" * filled + "▯" * (20 - filled)

    text_table = f"🔁 *Лупинг: {deposit_token} → {borrow_token}*\n"
    text_table += "```\n"
    text_table += f"{'Крг':<3} | {'Депозит':<15} | {'Долг':<15} | {'LTV':<6} | {'HF':<6} | {'Risk':<5} | {'net APY':<9} | Leverage\n"
    text_table += "-" * 100 + "\n"

    for row in rows:
        loop = row["loop"]
        deposit_str = f"{row['deposit_tokens']:.4f} {deposit_token}"
        borrow_str = f"{row['borrow_tokens']:.2f} {borrow_token}"
        ltv = f"{row['ltv']:.1f}%"
        hf = f"{hf_emoji(row['hf'])}{row['hf']:.2f}"
        risk = f"{row['risk']:.0f}%"
        apy_val = row["net_apy"]
        apy = f"{emoji(apy_val)}{apy_val:+.2f}%"
        leverage = row["deposit_tokens"] / data["initial_deposit"] if data["initial_deposit"] else 1

        text_table += f"{loop:>3} | {deposit_str:<15} | {borrow_str:<15} | {ltv:<6} | {hf:<6} | {risk:<5} | {apy:<9} | x{leverage:.2f}\n"

    text_table += "```"

    last = rows[-1]
    bar = draw_bar(last["reserve_pct"])

    text_info = ""

    if wrapper:
        text_info += f"🎁 *Бонус от обёртки залога:* +${wrapper:,.2f}\n"
    if borrow_wrapper:
        text_info += f"💸 *Экономия от обёртки займа:* +${borrow_wrapper:,.2f}\n"

    last_loop = last["loop"]
    if liquidated:
        text_info += f"\n⚠️ *На {last_loop}-м круге наступает ликвидация — расчёт остановлен.*"
    elif last_loop >= 10:
        text_info += f"\n⛔ *Достигнут лимит в {last_loop} кругов.*"

    text_info += f"\n\n📊 *Запас до ликвидации:* {last['reserve_pct']:.2f}%\n`{bar}`"

    # Сравнение с HODL
    base_invest = data["initial_deposit"] * deposit_price
    hodl_value = base_invest
    final_supply_value = data["final_deposit"] * deposit_price
    final_borrow_value = data["final_borrow"] * borrow_price
    net_balance = final_supply_value - final_borrow_value
    total_value = net_balance + wrapper + borrow_wrapper
    pnl = total_value - hodl_value
    pnl_pct = (pnl / hodl_value) * 100 if hodl_value else 0
    pnl_emoji = emoji(pnl_pct)

    text_info += "\n\n📈 *Сравнение с HODL:*\n"
    text_info += "```\n"
    text_info += f"{pnl_emoji} Баланс после лупинга: ${total_value:,.2f}\n"
    text_info += f"💼 HODL:               ${hodl_value:,.2f}\n"
    text_info += f"{pnl_emoji} Разница:             ${pnl:,.2f} ({pnl_pct:+.2f}%)\n"
    text_info += "```"

    # Доп. анализ
    avg_ltv = sum(row["ltv"] for row in rows) / len(rows)
    avg_hf = sum(row["hf"] for row in rows) / len(rows)
    final_leverage = data["final_deposit"] / data["initial_deposit"] if data["initial_deposit"] else 1

    ltv_icon = "🟢" if avg_ltv < 70 else "🟡" if avg_ltv < 80 else "🔴"
    hf_icon = "🟢" if avg_hf > 1.5 else "🟡" if avg_hf > 1.2 else "🔴"
    lev_icon = "🟢" if final_leverage <= 2 else "🟡" if final_leverage <= 4 else "🔴"

    text_info += "\n\n🧮 *Дополнительный анализ:*\n"
    text_info += f"{ltv_icon} 📊 Средний LTV: {avg_ltv:.2f}%\n"
    text_info += f"{hf_icon} 🧠 Средний HF: {avg_hf:.2f}\n"
    text_info += f"{lev_icon} ⚖️ Leverage: x{final_leverage:.2f} — сколько вырос твой капитал"

    # 🔻🔺 Критические цены ликвидации
    text_info += "\n\n📉 *Критические цены ликвидации:*\n\n"

    text_info += f"🔻 Если цена {deposit_token} упадёт до:\n"
    for row in rows:
        text_info += f"🔴 Круг {row['loop']}: ${row['price_collateral_liq']:.4f}\n"

    text_info += f"\n🔺 Если цена {borrow_token} вырастет до:\n"
    for row in rows:
        text_info += f"🟢 Круг {row['loop']}: ${row['price_debt_liq']:.4f}\n"

    return text_table, text_info