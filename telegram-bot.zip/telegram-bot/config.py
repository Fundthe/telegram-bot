import os
from dotenv import load_dotenv

load_dotenv()

# 🔑 Основной токен бота
BOT_TOKEN = os.getenv("BOT_TOKEN")

# 👮 ID администратора
ADMIN_ID = 7378689189  # можно тоже взять из переменной окружения, если хочешь

# 📊 Включить/выключить сбор статистики
ENABLE_STATS = True