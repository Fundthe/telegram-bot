from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from handlers.states import DCA_ADV_TOKEN, DCA_ADV_COUNT, DCA_ADV_ENTRIES, DCA_ADV_CURRENT, DCA_ADV_RESULT
from keyboards import back_button, back_to_menu_button
from utils import push_state, update_stats
from user_data import user_data_temp, last_bot_messages
import contextlib
from utils import delete_all_bot_messages, launch_with_cleanup


async def delete_all_bot_messages(context: ContextTypes.DEFAULT_TYPE, chat_id: int):
    messages = last_bot_messages.get(chat_id, [])
    for msg_id in messages:
        with contextlib.suppress(Exception):
            await context.bot.delete_message(chat_id=chat_id, message_id=msg_id)
    last_bot_messages[chat_id] = []


# 🔹 Старт из меню
async def start_dca_from_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    await update.callback_query.message.delete()

    await delete_all_bot_messages(context, chat_id)

    push_state(chat_id, DCA_ADV_TOKEN)
    msg1 = await context.bot.send_photo(chat_id=chat_id, photo="https://raw.githubusercontent.com/Fundthe/one/main/DCA1.png")
    msg2 = await context.bot.send_message(chat_id=chat_id, text="⚙️━━━━━Доп.меню📋━━━━━⚙️", reply_markup=back_button(DCA_ADV_TOKEN))

    last_bot_messages[chat_id] = [msg1.message_id, msg2.message_id]
    return DCA_ADV_TOKEN


# 🔹 Шаг 1 — токен
async def ask_dca_token(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message or update.callback_query.message
    try: await message.delete()
    except: pass

    push_state(message.chat_id, DCA_ADV_TOKEN)
    msg1 = await context.bot.send_photo(chat_id=message.chat_id, photo="https://raw.githubusercontent.com/Fundthe/one/main/DCA1.png")
    msg2 = await context.bot.send_message(chat_id=message.chat_id, text="⚙️━━━━━Доп.меню📋━━━━━⚙️", reply_markup=back_button(DCA_ADV_TOKEN))
    last_bot_messages.setdefault(message.chat_id, []).extend([msg1.message_id, msg2.message_id])
    return DCA_ADV_TOKEN

async def handle_dca_token(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try: await update.message.delete()
    except: pass

    token = update.message.text.strip().upper()
    user_data_temp[update.effective_chat.id] = {"dca": {"token": token}}
    return await ask_dca_count(update, context)


# 🔹 Шаг 2 — количество закупок
async def ask_dca_count(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, DCA_ADV_COUNT)
    msg1 = await context.bot.send_photo(chat_id=update.effective_chat.id, photo="https://raw.githubusercontent.com/Fundthe/one/main/DCA2.png")
    msg2 = await context.bot.send_message(chat_id=update.effective_chat.id, text="⚙️━━━━━Доп.меню📋━━━━━⚙️", reply_markup=back_button(DCA_ADV_COUNT))
    last_bot_messages.setdefault(update.effective_chat.id, []).extend([msg1.message_id, msg2.message_id])
    return DCA_ADV_COUNT

async def handle_dca_count(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try: await update.message.delete()
    except: pass

    try:
        count = int(update.message.text.strip())
        user_data_temp[update.effective_chat.id]["dca"]["count"] = count
        return await ask_dca_entries(update, context)
    except:
        await update.message.reply_text("❌ Введи количество закупок (целое число)")
        return DCA_ADV_COUNT


# 🔹 Шаг 3 — цена + объём
async def ask_dca_entries(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, DCA_ADV_ENTRIES)
    msg1 = await context.bot.send_photo(chat_id=update.effective_chat.id, photo="https://raw.githubusercontent.com/Fundthe/one/main/DCA3.png")
    msg2 = await context.bot.send_message(chat_id=update.effective_chat.id, text="⚙️━━━━━Доп.меню📋━━━━━⚙️", reply_markup=back_button(DCA_ADV_ENTRIES))
    last_bot_messages.setdefault(update.effective_chat.id, []).extend([msg1.message_id, msg2.message_id])
    return DCA_ADV_ENTRIES

async def handle_dca_entries(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try: await update.message.delete()
    except: pass

    text = update.message.text.strip().replace(" ", "")
    lines = text.split(",")

    try:
        entries = []
        for line in lines:
            if "+" not in line:
                continue
            price_str, qty_str = line.split("+")
            price = float(price_str.replace(",", "."))
            qty = float(qty_str.replace(",", "."))
            entries.append((price, qty))

        if not entries:
            raise ValueError("Нет корректных записей")

        expected = user_data_temp.get(update.effective_chat.id, {}).get("dca", {}).get("count", 0)
        if expected and len(entries) != expected:
            await update.message.reply_text(f"❌ Ты указал {len(entries)} записей, а должно быть {expected}")
            return DCA_ADV_ENTRIES

        user_data_temp[update.effective_chat.id]["dca"]["entries"] = entries
        return await ask_dca_current(update, context)

    except Exception as e:
        await update.message.reply_text(
            f"❌ Ошибка парсинга. Убедись, что ты вводишь пары `цена+объём`, например:\n`1000+1, 1000+1, 1000+1`",
            parse_mode="Markdown"
        )
        print("DCA парсинг ошибка:", e)
        return DCA_ADV_ENTRIES


# 🔹 Шаг 4 — текущая цена
async def ask_dca_current(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, DCA_ADV_CURRENT)
    msg1 = await context.bot.send_photo(chat_id=update.effective_chat.id, photo="https://raw.githubusercontent.com/Fundthe/one/main/DCA4.png")
    msg2 = await context.bot.send_message(chat_id=update.effective_chat.id, text="⚙️━━━━━Доп.меню📋━━━━━⚙️", reply_markup=back_button(DCA_ADV_CURRENT))
    last_bot_messages.setdefault(update.effective_chat.id, []).extend([msg1.message_id, msg2.message_id])
    return DCA_ADV_CURRENT

async def handle_dca_current(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try: await update.message.delete()
    except: pass

    try:
        current_price = float(update.message.text.strip().replace(",", "."))
        user_data_temp[update.effective_chat.id]["dca"]["current"] = current_price
        return await show_dca_result(update, context)
    except:
        await update.message.reply_text("❌ Введи текущую цену токена")
        return DCA_ADV_CURRENT


# 🔹 Финал — результат
async def show_dca_result(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    dca = user_data_temp.get(chat_id, {}).get("dca", {})
    token = dca.get("token")
    entries = dca.get("entries", [])
    current = dca.get("current", 0)
    count = dca.get("count", len(entries))

    total_spent = sum(price * qty for price, qty in entries)
    total_qty = sum(qty for _, qty in entries)
    avg_price = total_spent / total_qty if total_qty else 0
    current_value = current * total_qty
    pnl = current_value - total_spent
    pnl_pct = (pnl / total_spent * 100) if total_spent else 0
    emoji = "🟢" if pnl > 0 else "🔴" if pnl < 0 else "⚪️"

    result = f"""```
📊 Результаты DCA для {token}
━━━━━━━━━━━━━━━━━━━
Средняя цена: ${avg_price:.4f}
Текущая цена: ${current:.4f}
Кол-во токенов: {total_qty:.4f}

Потрачено: ${total_spent:.2f}
Текущая стоимость: ${current_value:.2f}
PnL: {emoji} ${pnl:.2f} | {pnl_pct:.2f}%
━━━━━━━━━━━━━━━━━━━
```"""

    update_stats("dca")
    await context.bot.send_message(chat_id=chat_id, text=result, parse_mode="Markdown")

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔁 Повторить расчет", callback_data="dca")],
        [InlineKeyboardButton("📋 В меню", callback_data="back")]
    ])
    await context.bot.send_message(chat_id=chat_id, text="Выбери действие:", reply_markup=keyboard)
    return DCA_ADV_RESULT