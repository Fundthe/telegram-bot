from telegram import Update
from telegram.ext import ContextTypes
from config import ADMIN_ID
from utils import update_stats, fix_cyrillic
from keyboards import back_button
from handlers.states import RATE, HOURS
from calculations.funding import calculate_simple
from handlers.menu import start
from user_data import user_data_temp, last_bot_messages
from utils import delete_all_bot_messages, launch_with_cleanup
import re
import contextlib





# ⬇️ вызывается при выборе "Фандинг" в меню (choice == "rate")
async def start_funding_from_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    await update.callback_query.message.delete()

    # Удаляем все сообщения от предыдущего захода в фандинг
    await delete_all_bot_messages(context, chat_id)

    msg1 = await context.bot.send_photo(
        chat_id,
        "https://raw.githubusercontent.com/Fundthe/one/main/Введи%20ставку%20финансирования.png"
    )

    msg2 = await context.bot.send_message(
        chat_id,
        "⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button(RATE)
    )

    # Сохраняем оба ID
    last_bot_messages[chat_id] = [msg1.message_id, msg2.message_id]
    return RATE


async def get_rate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        await update.message.delete()

        rate = float(update.message.text.strip().replace('%', ''))
        user_data_temp[update.effective_chat.id] = {'rate': rate}

        msg1 = await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo="https://raw.githubusercontent.com/Fundthe/one/main/Как%20часто%20начисляется%20ставка.png"
        )

        msg2 = await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
            reply_markup=back_button(RATE)
        )

        # Добавляем новые сообщения в список
        last_bot_messages.setdefault(update.effective_chat.id, []).extend([msg1.message_id, msg2.message_id])

        return HOURS

    except ValueError:
        await update.message.reply_text("❌ Пожалуйста, введи число. Например: 0.5")
        return RATE


async def get_hours(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        await update.message.delete()
        hours = float(update.message.text.strip().replace('ч', '').replace(' ', ''))
        rate = user_data_temp.get(update.effective_chat.id, {}).get('rate')

        if rate is None:
            await update.message.reply_text("❌ Ставка не найдена. Начни сначала.")
            return await start(update, context)

        simple = calculate_simple(rate, hours)

        response = (
            "*📈 Расчёт фандинга*\n"
            "```\n"
            f"{'Ставка финансирования:':<22} {rate}%\n"
            f"{'Начисляется каждые:':<22} {hours} ч\n"
            f"{'APR:':<22} {simple:.2f}%\n"
            "```"
        )

        msg = await update.message.reply_text(response, parse_mode="Markdown")
        last_bot_messages.setdefault(update.effective_chat.id, []).append(msg.message_id)

        update_stats(update.effective_user.id, module="funding")
        return await start(update, context)

    except Exception:
        await update.message.reply_text("❌ Что-то пошло не так. Попробуй ещё раз.")
        return RATE