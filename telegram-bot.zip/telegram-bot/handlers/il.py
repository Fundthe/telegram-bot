from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from handlers.states import IL_STEP1, IL_STEP2, IL_STEP3, IL_STEP4, IL_STEP5, CHOOSING
from utils import update_stats, push_state, pop_prev_state, parse_token_input, fix_cyrillic
from keyboards import back_button
from user_data import user_data_temp
from calculations.looping import calculate_apr
from utils import delete_all_bot_messages, launch_with_cleanup


# 🔙 Обработка кнопки "Назад"
async def back_callback_il(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    chat_id = update.effective_chat.id
    prev = pop_prev_state(chat_id)

    if prev == IL_STEP1:
        return await ask_il_step1(update, context)
    elif prev == IL_STEP2:
        return await ask_il_step2(update, context)
    elif prev == IL_STEP3:
        return await ask_il_step3(update, context)
    elif prev == IL_STEP4:
        return await ask_il_step4(update, context)
    else:
        return await ask_il_step1(update, context)

# Шаг 1
async def ask_il_step1(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message or update.callback_query.message
    push_state(message.chat_id, IL_STEP1)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/il1.png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button()
    )
    return IL_STEP1

async def get_il_step1(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        message = update.message or update.callback_query.message
        await message.delete()
        tokens = parse_token_input(message.text)
        user_data_temp[update.effective_chat.id] = {"il_entry": tokens}
        return await ask_il_step2(update, context)
    except:
        await update.message.reply_text("❌ Формат неверный. Пример: `ETH+4+1800, BTC+0.1+30000`", parse_mode="Markdown")
        return IL_STEP1

# Шаг 2
async def ask_il_step2(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, IL_STEP2)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/il2.png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button()
    )
    return IL_STEP2

async def get_il_step2(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        message = update.message or update.callback_query.message
        await message.delete()
        tokens = parse_token_input(message.text)
        user_data_temp[update.effective_chat.id]["il_exit"] = tokens
        return await ask_il_step3(update, context)
    except:
        await update.message.reply_text("❌ Формат неверный.")
        return IL_STEP2

# Шаг 3
async def ask_il_step3(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, IL_STEP3)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/il3.png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button()
    )
    return IL_STEP3

async def get_il_step3(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        message = update.message or update.callback_query.message
        await message.delete()
        text = message.text.strip()
        user_data_temp[update.effective_chat.id]["il_fees"] = parse_token_input(text)
        return await ask_il_step4(update, context)
    except:
        await update.message.reply_text("❌ Формат неверный.")
        return IL_STEP3

# Шаг 4
async def ask_il_step4(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, IL_STEP4)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/il4.png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button()
    )
    return IL_STEP4

async def get_il_step4(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message or update.callback_query.message
    await message.delete()
    text = message.text.strip()
    if text == "-":
        user_data_temp[update.effective_chat.id]["il_farming"] = None
    else:
        try:
            token, amount, price = text.split("+")
            user_data_temp[update.effective_chat.id]["il_farming"] = {
                "token": token.upper(), "amount": float(amount), "price": float(price)
            }
        except:
            await update.message.reply_text("❌ Формат неверный. Пример: ARB+15+2.3")
            return IL_STEP4

    return await ask_il_step5(update, context)

# Шаг 5
async def ask_il_step5(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, IL_STEP5)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/%D0%A1%D0%BA%D0%BE%D0%BB%D1%8C%D0%BA%D0%BE%20%D0%B4%D0%BD%D0%B5%D0%B9%20%D0%BF%D0%BE%D0%B7%D0%B8%D1%86%D0%B8%D0%B8%20_.png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button()
    )
    return IL_STEP5

async def get_il_step5(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message or update.callback_query.message
    await message.delete()
    text = message.text.strip()
    days = int(text) if text.isdigit() else None
    user_state = user_data_temp[update.effective_chat.id]
    user_state["il_days"] = days
    from handlers.il import show_il_summary
    return await show_il_summary(update, context)


async def show_il_summary(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = user_data_temp[update.effective_chat.id]
    entry = data["il_entry"]
    exit = data["il_exit"]
    fees = data["il_fees"]
    farming = data.get("il_farming")
    days = data.get("il_days")

    tokens = list(entry.keys())
    if len(tokens) != 2:
        await update.message.reply_text("❌ Поддерживаются только пары из 2 токенов.")
        return IL_STEP1

    t1, t2 = tokens
    e1, e2 = entry[t1], entry[t2]
    x1, x2 = exit[t1], exit[t2]

    invest = e1["amount"] * e1["price"] + e2["amount"] * e2["price"]
    half = invest / 2
    r1, r2 = x1["price"] / e1["price"], x2["price"] / e2["price"]
    k = r1 / r2
    il = (2 * (k ** 0.5) / (1 + k)) - 1
    hodl = half * r1 + half * r2
    pool = x1["amount"] * x1["price"] + x2["amount"] * x2["price"]
    fees_value = fees[t1]["amount"] * fees[t1]["price"] + fees[t2]["amount"] * fees[t2]["price"]
    farm_val = farming["amount"] * farming["price"] if farming else 0

    total = pool + fees_value + farm_val
    roi = ((total - invest) / invest) * 100
    fee_pct = (fees_value + farm_val) / invest * 100
    delta = total - hodl
    delta_pct = (delta / hodl) * 100 if hodl else 0
    min_fee_pct = max(hodl - pool, 0) / invest * 100
    apr = calculate_apr(roi, days) if days else None

    def emoji(pct):
        return "🟢" if pct > 0 else "🔴" if pct < 0 else "⚪️"

    emoji_il = emoji(-il)
    emoji_delta = emoji(delta)
    emoji_roi = emoji(roi)

    # Сообщение 1 — с отступами между блоками
    result_1 = "📊 *Имперманент Лосс: расчёт*\n```\n"
    result_1 += f"{emoji_il} Impermanent Loss:  {abs(il)*100:.2f}%\n→ Потери по сравнению с HODL, вызванные разным ростом/падением токенов.\n"

    result_1 += f"\n🪙 HODL:         ${hodl:,.2f}\n→ Сколько было бы при обычном хранении токенов\n"

    result_1 += f"\n🏊 Пул:          ${pool:,.2f}\n→ Сколько ты забрал из пула (без учёта комиссий/фарминга)\n"

    result_1 += f"\n💸 Комиссии:     +${fees_value:,.2f}\n→ Доход от обменов внутри пула\n"

    if farming:
        result_1 += f"\n🎁 Фарминг:      +${farm_val:,.2f} ({farming['token']})\n→ Вознаграждение за фарминг токенов\n"

    result_1 += f"\n💰 Итого:        ${total:,.2f}\n→ Пул + комиссии + фарминг (если был)"
    result_1 += "\n```"

    await update.message.reply_text(result_1, parse_mode="Markdown")

    # 📌 Анализ
    if abs(il) < 0.005:
        il_comment = "Ты *не получил impermanent loss* — цена токенов изменилась почти одинаково."
    elif il < 0:
        il_comment = f"Ты *получил impermanent loss* {abs(il)*100:.2f}% — токены изменились неравномерно."
    else:
        il_comment = f"IL = {abs(il)*100:.2f}% — расчёт нейтральный, но требует внимания."

    if roi < 0:
        roi_comment = "⚠️ *Итог убыточен* — пул не перекрыл потери. Возможно, слабая активность или неудачный момент входа."
    elif fee_pct >= abs(il*100):
        roi_comment = "✅ *Комиссии и фарминг перекрыли IL* и дали прибыль."
    elif fee_pct < abs(il*100):
        roi_comment = "📉 *Доход не перекрыл IL полностью* — результат ниже HODL."

    if apr:
        if apr < 10:
            apr_comment = "📉 Доходность слабая — пул вялый или малоактивный."
        elif 10 <= apr <= 20:
            apr_comment = "📊 Доходность нормальная — возможно, стабильный пул со средним трафиком."
        else:
            apr_comment = "🚀 Годовая доходность высокая — пул выглядит выгодным для долгосрока."
    else:
        apr_comment = ""

    if total > hodl:
        compare_comment = "🟢 Результат *лучше, чем HODL* — пул дал больше прибыли, чем просто хранение."
    elif total < hodl:
        compare_comment = "🔴 Результат *хуже, чем HODL* — проще было бы просто держать токены."
    else:
        compare_comment = "⚪️ Результат примерно равен HODL — пул не дал ни плюс, ни минус."

    # Сообщение 2 — аналитика
    summary_text = "```\n"
    summary_text += f"{emoji_delta} Разница:      ${delta:,.2f} ({delta_pct:+.2f}%)\n→ Насколько результат отличается от HODL\n"
    summary_text += f"{emoji_roi} ROI:          {roi:+.2f}%\n→ Возврат на инвестиции: сколько заработано от вложенной суммы\n"
    summary_text += f"📈 Комиссии/фарм: {fee_pct:+.2f}%\n→ Комиссии и фарминг в процентах от вложений\n"
    if apr:
        summary_text += f"🗓 APR:          {apr:.2f}%\n→ Годовая доходность, если продолжать в том же темпе\n"
    summary_text += f"📌 Безубыток:     ~{min_fee_pct:.2f}%\n→ Сколько нужно заработать, чтобы выйти хотя бы в ноль"
    summary_text += "\n```"

    summary_text += "\n📌 *Вывод:*\n"
    summary_text += f"{il_comment}\n{roi_comment}\n{apr_comment}\n{compare_comment}"

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔁 Повторить расчёт", callback_data="il")],
        [InlineKeyboardButton("📋 В меню", callback_data="back")]
    ])

    await update.message.reply_text(summary_text.strip(), parse_mode="Markdown", reply_markup=keyboard)
    update_stats(update.effective_user.id, module="il")
    return CHOOSING