from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from handlers.states import LOAN_DEP_AMOUNT, LOAN_BORROW_AMOUNT, LOAN_LTV, LOAN_THRESHOLD, CHOOSING
from utils import push_state, update_stats
from keyboards import back_button
from user_data import user_data_temp
from calculations.loan import calculate_health_factor
from utils import fix_cyrillic
import re
from utils import delete_all_bot_messages, launch_with_cleanup


async def get_loan_deposit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.delete()
    text = update.message.text.strip().replace(',', '.')
    try:
        token, amount, price = text.split("+")
        user_data_temp[update.effective_chat.id] = {
            "loan_deposit_token": token.upper(),
            "loan_deposit_amount": float(amount),
            "loan_deposit_price": float(price)
        }

        await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo="https://raw.githubusercontent.com/Fundthe/one/main/Введи%20актив%20который%20будешь%20брать%20займ.png"
        )
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
            reply_markup=back_button(LOAN_DEP_AMOUNT)
        )
        push_state(update.effective_chat.id, LOAN_BORROW_AMOUNT)
        return LOAN_BORROW_AMOUNT
    except:
        await update.message.reply_text("❌ Проверь формат. Пример: `ETH+2+1800`")
        return LOAN_DEP_AMOUNT


async def get_loan_borrow(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.delete()
    text = update.message.text.strip().replace(',', '.')
    try:
        token, amount, price = text.split("+")
        user_data_temp[update.effective_chat.id]["loan_borrow_token"] = token.upper()
        user_data_temp[update.effective_chat.id]["loan_borrow_amount"] = float(amount)
        user_data_temp[update.effective_chat.id]["loan_borrow_price"] = float(price)

        await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo="https://raw.githubusercontent.com/Fundthe/one/main/Напиши%20начальный%20LTV.png"
        )
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
            reply_markup=back_button(LOAN_BORROW_AMOUNT)
        )
        push_state(update.effective_chat.id, LOAN_LTV)
        return LOAN_LTV
    except:
        await update.message.reply_text("❌ Проверь формат. Пример: `USDC+1000+1`")
        return LOAN_BORROW_AMOUNT


async def get_loan_ltv(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        await update.message.delete()
        ltv = float(update.message.text.strip().replace(',', '.'))
        user_data_temp[update.effective_chat.id]["loan_ltv"] = ltv

        await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo="https://raw.githubusercontent.com/Fundthe/one/main/тот%20LTV%20при%20котором%20твоя%20позиция%20будет%20ликвидирована..png"
        )
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
            reply_markup=back_button(LOAN_LTV)
        )
        push_state(update.effective_chat.id, LOAN_THRESHOLD)
        return LOAN_THRESHOLD
    except ValueError:
        await update.message.reply_text("❌ Введи корректное число. Например: `75`")
        return LOAN_LTV


async def get_loan_threshold(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        await update.message.delete()
        threshold = float(update.message.text.strip().replace(',', '.'))
        chat_id = update.effective_chat.id
        state = user_data_temp[chat_id]

        state["deposit"] = {
            "token": state["loan_deposit_token"],
            "amount": state["loan_deposit_amount"],
            "price": state["loan_deposit_price"]
        }
        state["borrow"] = {
            "token": state["loan_borrow_token"],
            "amount": state["loan_borrow_amount"],
            "price": state["loan_borrow_price"]
        }

        col = state["deposit"]
        bor = state["borrow"]
        ltv = state["loan_ltv"]
        liq = threshold
        borrow_factor = 0.9

        calc = calculate_health_factor(
            deposit_amount=col["amount"],
            deposit_price=col["price"],
            borrow_amount=bor["amount"],
            borrow_price=bor["price"],
            liq_threshold=threshold,
            borrow_factor=borrow_factor
        )

        health_factor = calc["health_factor"]
        risk_factor = calc["risk_factor_pct"]
        reserve_pct = calc["reserve_pct"]
        col_val = calc["deposit_value"]
        bor_val = calc["borrow_value"]

        liq_price_col = (bor_val / col["amount"]) / (liq / 100)
        liq_price_bor = (col_val * (liq / 100)) / bor["amount"]
        liq_ratio = liq_price_col / bor["price"]

        def draw_bar(p):
            total = 20
            filled = int(min(max(p / 100, 0), 1) * total)
            empty = total - filled
            return "▮" * filled + "▯" * empty + f" {p:.2f}%"

        hf_status = "🟢" if health_factor > 1.5 else "🟡" if health_factor > 1 else "🔴"
        risk_status = "🟢" if risk_factor < 70 else "🟡" if risk_factor < 100 else "🔴"

        result = f"💳 *Анализ кредитования ({col['token']} → {bor['token']})*\n```"
        result += f"\n🔹 Ты заложил:   {col['amount']} {col['token']} × ${col['price']} = ${col_val:,.2f}"
        result += f"\n🔹 Взял в займ:  {bor['amount']} {bor['token']} × ${bor['price']} = ${bor_val:,.2f}"
        result += f"\n\n🔸 LTV:           {ltv:.2f}%"
        result += f"\n⚠️  Ликв. порог:  {liq:.2f}%"
        result += f"\n🧮 Borrow Factor: {borrow_factor}"
        result += f"\n\n📉 Ликв. цена {col['token']}:  ${liq_price_col:,.4f}"
        result += f"\n📈 Ликв. цена {bor['token']}:  ${liq_price_bor:,.4f}"
        result += f"\n💱 При курсе {col['token']}/{bor['token']} = {liq_ratio:.6f} произойдёт ликвидация"
        result += f"\n\n🧠 Health Factor: {health_factor:.2f} {hf_status} — {'безопасно' if health_factor > 1 else 'риск ликвидации'}"
        result += f"\n📌 Ликвидация начнётся, если он опустится до 1.00 или ниже"
        result += f"\n\n📛 Risk Factor:   {risk_factor:.2f}% {risk_status} — {'низкий риск' if risk_factor < 100 else 'высокий риск'}"
        result += f"\n📌 Ликвидация наступит, если риск поднимется до 100%"
        result += f"\n\n📊 До ликвидации: {reserve_pct:.2f}%"
        result += "\n" + draw_bar(reserve_pct)

        if col["token"] != bor["token"]:
            result += "\n\n📊 Сценарии ликвидации:"
            result += f"\n🔹 {col['token']} = ${col['price']:.4f}  →"
            result += f"\n   🟢 {bor['token']} растёт до ${liq_price_bor:.4f} → ЛИКВИДАЦИЯ"
            result += f"\n   🔴 {bor['token']} падает — безопасно"
            result += f"\n\n🔹 {bor['token']} = ${bor['price']:.4f}  →"
            result += f"\n   🔴 {col['token']} падает до ${liq_price_col:.4f} → ЛИКВИДАЦИЯ"
            result += f"\n   🟢 {col['token']} растёт — безопасно"
        else:
            result += "\n\n📊 Сценарии:"
            result += "\nЗалог и займ в одной монете — сценарии не применимы."

        result += "\n```"

        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔁 Заново", callback_data="loan")],
            [InlineKeyboardButton("🔙 В меню", callback_data="back")]
        ])

        await update.message.reply_text(result.strip(), parse_mode='Markdown', reply_markup=keyboard)
        update_stats(update.effective_user.id, module="loan")
        return CHOOSING

    except ValueError:
        await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo="https://raw.githubusercontent.com/Fundthe/one/main/тот%20LTV%20при%20котором%20твоя%20позиция%20будет%20ликвидирована..png"
        )
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
            reply_markup=back_button(LOAN_THRESHOLD)
        )
        await update.message.reply_text("❌ Введи число. Пример: 80")
        return LOAN_THRESHOLD