from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from utils import fix_cyrillic
from utils import pop_prev_state
from handlers.states import (
    LOOP_ADV_STEP1, LOOP_ADV_WRAPPER, LOOP_ADV_BORROW_WRAPPER, LOOP_ADV_LTV,
    LOOP_ADV_LTV_LIQ, LOOP_ADV_RATES, LOOP_ADV_DAYS, CHOOSING
)
from keyboards import back_button, wrapper_keyboard
from user_data import user_data_temp
from utils import push_state, update_stats
from utils import delete_all_bot_messages, launch_with_cleanup
from calculations.looping import (
    calculate_looping_advanced,
    format_looping_result
)

import re


# 🔹 Шаг 1 — старт
async def looping_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message or update.callback_query.message
    try: await message.delete()
    except: pass

    push_state(message.chat_id, LOOP_ADV_STEP1)  # 👈 Вот это нужно!

    await context.bot.send_photo(
        chat_id=message.chat_id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/лупинг1.png"
    )
    await context.bot.send_message(
        chat_id=message.chat_id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button(LOOP_ADV_STEP1)
    )
    return LOOP_ADV_STEP1


# 🔹 Шаг 2 — ввод депозита и займа
async def handle_deposit_and_borrow(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    text = update.message.text.strip().upper().replace(" ", "")
    text = fix_cyrillic(text)

    if "," not in text or "+" not in text:
        await update.message.reply_text("❌ Неверный формат. Пример: ETH+2+1800, USDC+2000+1")
        return LOOP_ADV_STEP1

    try:
        part1, part2 = text.split(",")

        def parse(p):
            parts = p.split("+")
            if len(parts) != 3:
                raise ValueError("Неверный формат")
            token, amount, price = parts
            if not re.fullmatch(r'[A-Z0-9]{2,10}', token):
                raise ValueError(f"Монета `{token}` указана с ошибкой. Используй латиницу.")
            return token, float(amount), float(price)

        dep_token, dep_amount, dep_price = parse(part1)
        bor_token, bor_amount, bor_price = parse(part2)

    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка: {e}\nПример: ETH+2+1800, USDC+2000+1")
        return LOOP_ADV_STEP1

    user_data_temp[chat_id] = {
        "loop": {
            "deposit_token": dep_token,
            "deposit_amount": dep_amount,
            "deposit_price": dep_price,
            "borrow_token": bor_token,
            "borrow_amount": bor_amount,
            "borrow_price": bor_price
        }
    }

    return await ask_wrapper_supply(update, context)


# 🔹 Шаг 3 — supply wrapper
async def ask_wrapper_supply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, LOOP_ADV_WRAPPER)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/%D0%BB%D1%83%D0%BF%D0%B8%D0%BD%D0%B32%20_.png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=wrapper_keyboard("no_wrapper")
    )
    return LOOP_ADV_WRAPPER


async def handle_wrapper_supply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = fix_cyrillic(update.message.text.strip().upper())
    chat_id = update.effective_chat.id

    if "+" not in text:
        await update.message.reply_text("❌ Неверный формат. Пример: wstETH+5")
        return LOOP_ADV_WRAPPER

    try:
        token, bonus = text.split("+")
        user_data_temp[chat_id]["loop"].update({
            "wrapper_token": token,
            "wrapper_bonus": float(bonus)
        })
    except:
        await update.message.reply_text("❌ Неверный формат. Пример: wstETH+5")
        return LOOP_ADV_WRAPPER

    return await ask_wrapper_borrow(update, context)


# 🔹 Шаг 4 — borrow wrapper
async def ask_wrapper_borrow(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, LOOP_ADV_BORROW_WRAPPER)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/%D0%BB%D1%83%D0%BF%D0%B8%D0%BD%D0%B33%20_.png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=wrapper_keyboard("no_borrow_wrapper")
    )
    return LOOP_ADV_BORROW_WRAPPER


async def handle_wrapper_borrow(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = fix_cyrillic(update.message.text.strip().upper())
    chat_id = update.effective_chat.id

    if "+" not in text:
        await update.message.reply_text("❌ Неверный формат. Пример: wstETH+5")
        return LOOP_ADV_BORROW_WRAPPER

    try:
        token, bonus = text.split("+")
        user_data_temp[chat_id]["loop"].update({
            "borrow_wrapper_token": token,
            "borrow_wrapper_bonus": float(bonus)
        })
    except:
        await update.message.reply_text("❌ Неверный формат. Пример: wstETH+5")
        return LOOP_ADV_BORROW_WRAPPER

    return await ask_ltv(update, context)


# 🔹 Шаг 5 — LTV
async def ask_ltv(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, LOOP_ADV_LTV)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/Напиши%20начальный%20LTV.png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button(LOOP_ADV_LTV)
    )
    return LOOP_ADV_LTV

async def handle_ltv(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    text = update.message.text.strip()

    if not text.isdigit():
        await update.message.reply_text("❌ Введи число — например: 75")
        return LOOP_ADV_LTV

    user_data_temp[chat_id]["loop"]["ltv"] = int(text)
    return await ask_liq_ltv(update, context)



# 🔹 Шаг 6 — ликвидационный LTV
async def ask_liq_ltv(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, LOOP_ADV_LTV_LIQ)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/тот%20LTV%20при%20котором%20твоя%20позиция%20будет%20ликвидирована..png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button(LOOP_ADV_LTV_LIQ)
    )
    return LOOP_ADV_LTV_LIQ

async def handle_liq_ltv(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    text = update.message.text.strip().replace(",", ".")

    try:
        value = float(text)
        user_data_temp[chat_id]["loop"]["ltv_liq"] = value
    except:
        await update.message.reply_text("❌ Введи число — например: 90")
        return LOOP_ADV_LTV_LIQ

    return await ask_rates(update, context)


# 🔹 Шаг 7 — проценты
async def ask_rates(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, LOOP_ADV_RATES)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/Напиши%20%25%20по%20депозиту%20и%20займу.png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button(LOOP_ADV_RATES)
    )
    return LOOP_ADV_RATES

async def handle_rates(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    text = update.message.text.strip().upper().replace(" ", "")

    try:
        token1, rate1 = text.split(",")[0].split("+")
        token2, rate2 = text.split(",")[1].split("+")
        loop = user_data_temp[chat_id]["loop"]
        loop["deposit_rate"] = float(rate1)
        loop["borrow_rate"] = float(rate2)
    except:
        await update.message.reply_text("❌ Неверный формат. Пример: ETH+12, USDC+6")
        return LOOP_ADV_RATES

    return await ask_days(update, context)


# 🔹 Шаг 8 — сколько дней
async def ask_days(update: Update, context: ContextTypes.DEFAULT_TYPE):
    push_state(update.effective_chat.id, LOOP_ADV_DAYS)
    await context.bot.send_photo(
        chat_id=update.effective_chat.id,
        photo="https://raw.githubusercontent.com/Fundthe/one/main/Сколько%20дней%20позиции%20_.png"
    )
    await context.bot.send_message(
        chat_id=update.effective_chat.id,
        text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
        reply_markup=back_button(LOOP_ADV_DAYS)
    )
    return LOOP_ADV_DAYS

async def handle_days(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    text = update.message.text.strip()
    loop = user_data_temp[chat_id]["loop"]

    if text == "-":
        loop["days"] = None
    else:
        try:
            loop["days"] = int(text)
        except:
            await update.message.reply_text("❌ Введи число или -")
            return LOOP_ADV_DAYS

    try:
        result = calculate_looping_advanced(
            deposit_token=loop["deposit_token"],
            deposit_amount=loop["deposit_amount"],
            deposit_price=loop["deposit_price"],
            deposit_rate=loop["deposit_rate"],
            borrow_token=loop["borrow_token"],
            borrow_amount=loop["borrow_amount"],
            borrow_price=loop["borrow_price"],
            borrow_rate=loop["borrow_rate"],
            ltv_target=loop["ltv"],
            ltv_liquidation=loop["ltv_liq"],
            wrapper_bonus_pct=loop.get("wrapper_bonus"),
            borrow_wrapper_bonus_pct=loop.get("borrow_wrapper_bonus"),
            days=loop.get("days")
        )
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка: {e}\nПопробуй заново.")
        return LOOP_ADV_STEP1

    table, info = format_looping_result(result)
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔁 Повторить", callback_data="looping")],
        [InlineKeyboardButton("📋 В меню", callback_data="back")]
    ])
    await context.bot.send_message(chat_id=chat_id, text=table, parse_mode="Markdown")
    await context.bot.send_message(chat_id=chat_id, text=info, parse_mode="Markdown", reply_markup=keyboard)
    update_stats(chat_id, module="looping")
    return CHOOSING


# 🔹 Callback — если нажал кнопку «Нет»
async def no_wrapper_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    return await ask_wrapper_borrow(update, context)

async def no_borrow_wrapper_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    return await ask_ltv(update, context)

async def back_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    chat_id = update.effective_chat.id
    prev_state = pop_prev_state(chat_id)

    if prev_state == LOOP_ADV_WRAPPER:
        return await ask_wrapper_supply(update, context)
    elif prev_state == LOOP_ADV_BORROW_WRAPPER:
        return await ask_wrapper_borrow(update, context)
    elif prev_state == LOOP_ADV_LTV:
        return await ask_ltv(update, context)
    elif prev_state == LOOP_ADV_LTV_LIQ:
        return await ask_liq_ltv(update, context)
    elif prev_state == LOOP_ADV_RATES:
        return await ask_rates(update, context)
    elif prev_state == LOOP_ADV_DAYS:
        return await ask_days(update, context)
    else:
        return await looping_start(update, context)