from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from keyboards import back_button, back_to_menu_button, wrapper_keyboard
from utils import launch_with_cleanup
from handlers.states import (
    CHOOSING,

    # 🔁 Лупинг
    LOOP_ADV_STEP1, LOOP_ADV_WRAPPER, LOOP_ADV_BORROW_WRAPPER,
    LOOP_ADV_LTV, LOOP_ADV_LTV_LIQ, LOOP_ADV_RATES, LOOP_ADV_DAYS,

    # 📈 Ставка финансирования
    RATE, HOURS,

    # 💳 Кредитование
    LOAN_DEP_AMOUNT, LOAN_BORROW_AMOUNT, LOAN_LTV, LOAN_THRESHOLD,

    # 💰 Impermanent Loss
    IL_STEP1, IL_STEP2, IL_STEP3, IL_STEP4, IL_STEP5,

    # 📉 PnL
    PNL_ENTRY_PRICE, PNL_EXIT_PRICE, PNL_AMOUNT, PNL_FEE, PNL_POSITION_TYPE,

    # 📊 DCA (новый)
     DCA_ADV_TOKEN, DCA_ADV_COUNT, DCA_ADV_ENTRIES, DCA_ADV_CURRENT, DCA_ADV_RESULT
)
from user_data import user_data_temp
from utils import push_state, pop_prev_state, update_stats
from handlers.prompts import STATE_PROMPTS


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("📈 Ставка финансирования", callback_data="rate"),
         InlineKeyboardButton("🔁 Лупинг/Leverage", callback_data="looping")],
        [InlineKeyboardButton("💳 Borrow", callback_data="loan"),
         InlineKeyboardButton("📉 Pool liquidity v2/v3", callback_data="il")],
        [InlineKeyboardButton("📉 Расчёт PnL по сделкам", callback_data="pnl"),
         InlineKeyboardButton("📊 DCA (средняя цена)", callback_data="dca_mass")]
    ])

    if update.message:
        await update.message.reply_text("*📋 Главное меню калькулятора*", parse_mode='Markdown', reply_markup=keyboard)
    elif update.callback_query:
        await update.callback_query.message.edit_text("📋 Главное меню\n\n🔽 Выбери один из вариантов:", reply_markup=keyboard)

    return CHOOSING

async def choose_option(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = query.from_user.id
    choice = query.data

    if choice == "back":
        user_data_temp[chat_id] = {}
        await start(update, context)
        return CHOOSING

    elif choice == "step_back":
        prev_state = pop_prev_state(chat_id)
        loop = user_data_temp.get(chat_id, {}).get("loop", {})

        # --- 🔁 Лупинг ---
        if prev_state == LOOP_ADV_STEP1:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOOP_ADV_STEP1], parse_mode="Markdown", reply_markup=back_to_menu_button())
            return LOOP_ADV_STEP1
        elif prev_state == LOOP_ADV_WRAPPER:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOOP_ADV_WRAPPER], parse_mode="Markdown", reply_markup=wrapper_keyboard("no_wrapper"))
            return LOOP_ADV_WRAPPER
        elif prev_state == LOOP_ADV_BORROW_WRAPPER:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOOP_ADV_BORROW_WRAPPER], parse_mode="Markdown", reply_markup=wrapper_keyboard("no_borrow_wrapper"))
            return LOOP_ADV_BORROW_WRAPPER
        elif prev_state == LOOP_ADV_LTV:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOOP_ADV_LTV], parse_mode="Markdown", reply_markup=back_button(menu=True))
            return LOOP_ADV_LTV
        elif prev_state == LOOP_ADV_LTV_LIQ:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOOP_ADV_LTV_LIQ], parse_mode="Markdown", reply_markup=back_button(menu=True))
            return LOOP_ADV_LTV_LIQ
        elif prev_state == LOOP_ADV_RATES:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOOP_ADV_RATES], parse_mode="Markdown", reply_markup=back_button(menu=True))
            return LOOP_ADV_RATES
        elif prev_state == LOOP_ADV_DAYS:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOOP_ADV_DAYS], parse_mode="Markdown", reply_markup=back_button(menu=True))
            return LOOP_ADV_DAYS

        # --- 📈 Funding Rate ---
        elif prev_state == RATE:
            await context.bot.send_message(chat_id, "📈 Введи ставку финансирования (%):", reply_markup=back_to_menu_button())
            return RATE
        elif prev_state == HOURS:
            await context.bot.send_message(chat_id, "⏱Как часто начисляется ставка? (в часах)", reply_markup=back_button(RATE))
            return HOURS

        # --- 💳 Loan ---
        elif prev_state == LOAN_DEP_AMOUNT:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOAN_DEP_AMOUNT], parse_mode="Markdown", reply_markup=back_to_menu_button())
            return LOAN_DEP_AMOUNT
        elif prev_state == LOAN_BORROW_AMOUNT:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOAN_BORROW_AMOUNT], parse_mode="Markdown", reply_markup=back_button(LOAN_DEP_AMOUNT))
            return LOAN_BORROW_AMOUNT
        elif prev_state == LOAN_LTV:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOAN_LTV], parse_mode="Markdown", reply_markup=back_button(LOAN_BORROW_AMOUNT))
            return LOAN_LTV
        elif prev_state == LOAN_THRESHOLD:
            await context.bot.send_message(chat_id, STATE_PROMPTS[LOAN_THRESHOLD], parse_mode="Markdown", reply_markup=back_button(LOAN_LTV))
            return LOAN_THRESHOLD

        # --- 📉 IL ---
        elif prev_state == IL_STEP1:
            await context.bot.send_message(chat_id, STATE_PROMPTS[IL_STEP1], parse_mode="Markdown", reply_markup=back_to_menu_button())
            return IL_STEP1
        elif prev_state == IL_STEP2:
            await context.bot.send_message(chat_id, STATE_PROMPTS[IL_STEP2], parse_mode="Markdown", reply_markup=back_button(IL_STEP2))
            return IL_STEP2
        elif prev_state == IL_STEP3:
            await context.bot.send_message(chat_id, STATE_PROMPTS[IL_STEP3], parse_mode="Markdown", reply_markup=back_button(IL_STEP3))
            return IL_STEP3
        elif prev_state == IL_STEP4:
            await context.bot.send_message(chat_id, STATE_PROMPTS[IL_STEP4], parse_mode="Markdown", reply_markup=back_button(IL_STEP4))
            return IL_STEP4
        elif prev_state == IL_STEP5:
            await context.bot.send_message(chat_id, STATE_PROMPTS[IL_STEP5], parse_mode="Markdown", reply_markup=back_button(IL_STEP5))
            return IL_STEP5
        #dca
        elif prev_state == DCA_ADV_TOKEN:
            from handlers.dca import ask_dca_token
            return await ask_dca_token(update, context)
        elif prev_state == DCA_ADV_COUNT:
            from handlers.dca import ask_dca_count
            return await ask_dca_count(update, context)
        elif prev_state == DCA_ADV_ENTRIES:
            from handlers.dca import ask_dca_entries
            return await ask_dca_entries(update, context)
        elif prev_state == DCA_ADV_CURRENT:
            from handlers.dca import ask_dca_current
            return await ask_dca_current(update, context)
        

        # --- 📉 PnL ---
        elif prev_state == PNL_ENTRY_PRICE:
            await context.bot.send_message(chat_id, "💵 Введи цену входа:", reply_markup=back_to_menu_button())
            return PNL_ENTRY_PRICE
        elif prev_state == PNL_EXIT_PRICE:
            await context.bot.send_message(chat_id, "📈 Введи цену выхода:", reply_markup=back_button(PNL_ENTRY_PRICE))
            return PNL_EXIT_PRICE
        elif prev_state == PNL_AMOUNT:
            await context.bot.send_message(chat_id, "📦 Введи объём позиции (в токенах):", reply_markup=back_button(PNL_EXIT_PRICE))
            return PNL_AMOUNT
        elif prev_state == PNL_FEE:
            await context.bot.send_message(chat_id, "💸 Введи комиссию в % (на каждую сделку):", reply_markup=back_button(PNL_AMOUNT))
            return PNL_FEE

        else:
            await start(update, context)
            return CHOOSING

    elif choice == "looping":
        from handlers.looping import looping_start
        return await launch_with_cleanup(update, context, chat_id, looping_start, module_key="loop")

    elif choice == "dca_mass":
        from handlers.dca import ask_dca_token
        from utils import launch_with_cleanup
        return await launch_with_cleanup(update, context, chat_id, ask_dca_token, module_key="dca_mass")

    elif choice == "dca":
        from handlers.dca import start_dca_from_menu
        return await launch_with_cleanup(update, context, chat_id, start_dca_from_menu, module_key="dca")


    elif choice == "rate":
        from handlers.funding import start_funding_from_menu
        return await launch_with_cleanup(update, context, chat_id, start_funding_from_menu)

    elif choice == "loan":
        from user_data import last_bot_messages
        await launch_with_cleanup(update, context, chat_id, lambda u, c: context.bot.send_photo(chat_id, "https://raw.githubusercontent.com/Fundthe/one/main/Введи%20актив%20который%20будет%20в%20залоге.png"), module_key="loan")
        await context.bot.send_message(chat_id, "⚙️━━━━━Доп.меню📋━━━━━⚙️", reply_markup=back_to_menu_button())
        return LOAN_DEP_AMOUNT

    elif choice == "il":
        from handlers.il import ask_il_step1
        return await launch_with_cleanup(update, context, chat_id, ask_il_step1, module_key="il")

    elif choice == "pnl":
        await launch_with_cleanup(update, context, chat_id, lambda u, c: context.bot.send_photo(chat_id, "https://raw.githubusercontent.com/Fundthe/one/main/Введи%20цену%20покупки%20монеты.png"), module_key="pnl")
        await context.bot.send_message(chat_id, "⚙️━━━━━Доп.меню📋━━━━━⚙️", reply_markup=back_to_menu_button())
        return PNL_ENTRY_PRICE

    elif choice == "pnl_long":
        user = user_data_temp.get(chat_id, {})
        entry = user.get("entry")
        exit_ = user.get("exit")
        amount = user.get("amount")
        fee = user.get("fee", 0)

        if None in [entry, exit_, amount]:
            await query.message.reply_text("❌ Не хватает данных. Начни сначала.")
            return await start(update, context)

    # 🔥 Удаляем все старые сообщения
        from utils import delete_all_bot_messages
        await delete_all_bot_messages(context, chat_id)

        fee_pct = fee / 100
        pnl = (exit_ - entry) * amount
        pnl_fee = (entry + exit_) * amount * fee_pct
        pnl_net = pnl - pnl_fee
        pnl_pct = (pnl_net / (entry * amount)) * 100 if entry else 0
        emoji = "🟢" if pnl_net > 0 else "🔴" if pnl_net < 0 else "⚪️"

        result = (
            f"📈 *PnL по сделке (Long)*\n"
            "```\n"
            f"Цена входа:   ${entry}\n"
            f"Цена выхода:  ${exit_}\n"
            f"Объём:        {amount}\n"
            f"Комиссия:     {fee}% на вход и выход\n"
            "-------------------------\n"
            f"{emoji} Чистый PnL:   ${pnl_net:,.2f} ({pnl_pct:+.2f}%)\n"
            "```"
        )

        await context.bot.send_message(chat_id, result, parse_mode="Markdown", reply_markup=back_to_menu_button())
        update_stats(chat_id, module="pnl")
        return CHOOSING

    elif choice == "pnl_short":
        user = user_data_temp.get(chat_id, {})
        entry = user.get("entry")
        exit_ = user.get("exit")
        amount = user.get("amount")
        fee = user.get("fee", 0)

        if None in [entry, exit_, amount]:
            await query.message.reply_text("❌ Не хватает данных. Начни сначала.")
            return await start(update, context)

    # 🔥 Удаляем все старые сообщения
        from utils import delete_all_bot_messages
        await delete_all_bot_messages(context, chat_id)

        fee_pct = fee / 100
        pnl = (entry - exit_) * amount
        pnl_fee = (entry + exit_) * amount * fee_pct
        pnl_net = pnl - pnl_fee
        pnl_pct = (pnl_net / (entry * amount)) * 100 if entry else 0
        emoji = "🟢" if pnl_net > 0 else "🔴" if pnl_net < 0 else "⚪️"

        result = (
            f"📉 *PnL по сделке (Short)*\n"
            "```\n"
            f"Цена входа:   ${entry}\n"
            f"Цена выхода:  ${exit_}\n"
            f"Объём:        {amount}\n"
            f"Комиссия:     {fee}% на вход и выход\n"
            "-------------------------\n"
            f"{emoji} Чистый PnL:   ${pnl_net:,.2f} ({pnl_pct:+.2f}%)\n"
            "```"
        )

        await context.bot.send_message(chat_id, result, parse_mode="Markdown", reply_markup=back_to_menu_button())
        update_stats(chat_id, module="pnl")
        return CHOOSING

    else:
        try:
            await query.message.delete()
        except:
            pass
        await context.bot.send_message(chat_id, "⚠️ Неизвестная команда. Возвращаю в меню.", reply_markup=back_to_menu_button())
        return CHOOSING