from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from utils import update_stats, push_state
from keyboards import back_button, back_to_menu_button
from handlers.menu import start
from handlers.states import CHOOSING, PNL_ENTRY_PRICE, PNL_EXIT_PRICE, PNL_AMOUNT, PNL_FEE, PNL_POSITION_TYPE
from user_data import user_data_temp
from utils import fix_cyrillic
from utils import delete_all_bot_messages, launch_with_cleanup
import re

async def get_pnl_entry(update: Update, context: ContextTypes.DEFAULT_TYPE):
  try:
      price = float(update.message.text.strip().replace(',', '.'))
      user_data_temp[update.effective_chat.id] = {'entry': price}

      await update.message.delete()

      await context.bot.send_photo(
          chat_id=update.effective_chat.id,
          photo="https://raw.githubusercontent.com/Fundthe/one/main/Введи%20цену%20продажи%20монеты.png"
      )
      await context.bot.send_message(
          chat_id=update.effective_chat.id,
          text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
          reply_markup=back_button(PNL_ENTRY_PRICE)
      )

      push_state(update.effective_chat.id, PNL_EXIT_PRICE)
      return PNL_EXIT_PRICE
  except:
      await update.message.reply_text("❌ Введи число. Пример: 1000")
      return PNL_ENTRY_PRICE

async def get_pnl_exit(update: Update, context: ContextTypes.DEFAULT_TYPE):
  try:
      price = float(update.message.text.strip().replace(',', '.'))
      user_data_temp[update.effective_chat.id]['exit'] = price

      await update.message.delete()

      await context.bot.send_photo(
          chat_id=update.effective_chat.id,
          photo="https://raw.githubusercontent.com/Fundthe/one/main/Введи%20размер%20позиции%20в%20монетах.png"
      )
      await context.bot.send_message(
          chat_id=update.effective_chat.id,
          text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
          reply_markup=back_button(PNL_EXIT_PRICE)
      )

      push_state(update.effective_chat.id, PNL_AMOUNT)
      return PNL_AMOUNT
  except:
      await update.message.reply_text("❌ Введи число.")
      return PNL_EXIT_PRICE

async def get_pnl_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
  try:
      amount = float(update.message.text.strip().replace(',', '.'))
      user_data_temp[update.effective_chat.id]['amount'] = amount

      await update.message.delete()

      await context.bot.send_photo(
          chat_id=update.effective_chat.id,
          photo="https://raw.githubusercontent.com/Fundthe/one/main/Введи%20комиссию%20в%20%25%20за%20сделки.png"
      )
      await context.bot.send_message(
          chat_id=update.effective_chat.id,
          text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
          reply_markup=back_button(PNL_AMOUNT)
      )

      push_state(update.effective_chat.id, PNL_FEE)
      return PNL_FEE
  except:
      await update.message.reply_text("❌ Введи число.")
      return PNL_AMOUNT

async def get_pnl_fee(update: Update, context: ContextTypes.DEFAULT_TYPE):
  try:
      fee = float(update.message.text.strip().replace(',', '.'))
      user_data_temp[update.effective_chat.id]['fee'] = fee

      await update.message.delete()

      await context.bot.send_photo(
          chat_id=update.effective_chat.id,
          photo="https://raw.githubusercontent.com/Fundthe/one/main/Long%20или%20Short.png"
      )
      await context.bot.send_message(
          chat_id=update.effective_chat.id,
          text="⚙️━━━━━Доп.меню📋━━━━━⚙️",
          reply_markup=InlineKeyboardMarkup([
              [InlineKeyboardButton("✅ Long", callback_data="pnl_long"),
               InlineKeyboardButton("🔻 Short", callback_data="pnl_short")]
          ])
      )

      push_state(update.effective_chat.id, PNL_POSITION_TYPE)
      return PNL_POSITION_TYPE
  except:
      await update.message.reply_text("❌ Введи число.")
      return PNL_FEE

async def pnl_long(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = query.from_user.id

    user = user_data_temp.get(chat_id, {})
    entry = user.get("entry")
    exit_ = user.get("exit")
    amount = user.get("amount")
    fee = user.get("fee", 0)

    if None in [entry, exit_, amount]:
        await query.message.reply_text("❌ Не хватает данных. Начни сначала.")
        return await start(update, context)

    fee_pct = fee / 100
    pnl = (exit_ - entry) * amount
    pnl_fee = (entry + exit_) * amount * fee_pct
    pnl_net = pnl - pnl_fee
    pnl_pct = (pnl_net / (entry * amount)) * 100 if entry else 0
    emoji = "🟢" if pnl_net > 0 else "🔴" if pnl_net < 0 else "⚪️"

    result = (
        f"📈 *PnL по сделке (Long)*\n"
        "```\n"
        f"Цена входа:   ${entry}\n"
        f"Цена выхода:  ${exit_}\n"
        f"Объём:        {amount}\n"
        f"Комиссия:     {fee}% на вход и выход\n"
        "-------------------------\n"
        f"{emoji} Чистый PnL:   ${pnl_net:,.2f} ({pnl_pct:+.2f}%)\n"
        "```"
    )

    await query.message.edit_text(result, parse_mode="Markdown", reply_markup=back_to_menu_button())
    update_stats(chat_id, module="pnl")
    return CHOOSING


async def pnl_short(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = query.from_user.id

    user = user_data_temp.get(chat_id, {})
    entry = user.get("entry")
    exit_ = user.get("exit")
    amount = user.get("amount")
    fee = user.get("fee", 0)

    if None in [entry, exit_, amount]:
        await query.message.reply_text("❌ Не хватает данных. Начни сначала.")
        return await start(update, context)

    fee_pct = fee / 100
    pnl = (entry - exit_) * amount
    pnl_fee = (entry + exit_) * amount * fee_pct
    pnl_net = pnl - pnl_fee
    pnl_pct = (pnl_net / (entry * amount)) * 100 if entry else 0
    emoji = "🟢" if pnl_net > 0 else "🔴" if pnl_net < 0 else "⚪️"

    result = (
        f"📉 *PnL по сделке (Short)*\n"
        "```\n"
        f"Цена входа:   ${entry}\n"
        f"Цена выхода:  ${exit_}\n"
        f"Объём:        {amount}\n"
        f"Комиссия:     {fee}% на вход и выход\n"
        "-------------------------\n"
        f"{emoji} Чистый PnL:   ${pnl_net:,.2f} ({pnl_pct:+.2f}%)\n"
        "```"
    )

    await query.message.edit_text(result, parse_mode="Markdown", reply_markup=back_to_menu_button())
    update_stats(chat_id, module="pnl")
    return CHOOSING