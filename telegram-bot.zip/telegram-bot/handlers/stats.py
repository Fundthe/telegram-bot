from telegram import Update
from telegram.ext import ContextTypes
from replit import db

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    users = db.get("users", {})
    modules = db.get("modules", {})
    total_runs = db.get("total_runs", 0)

    msg = f"📊 <b>Статистика</b>\n"
    msg += f"👥 Пользователей: <b>{len(users)}</b>\n"
    msg += f"🔁 Всего запусков: <b>{total_runs}</b>\n"

    if modules:
        msg += "\n<b>📈 По разделам:</b>\n"
        for module, count in modules.items():
            msg += f"• {module}: {count}\n"

    await update.message.reply_text(msg, parse_mode="HTML")