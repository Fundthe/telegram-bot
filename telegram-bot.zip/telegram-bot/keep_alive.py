from flask import Flask
from threading import Thread

app_web = Flask('')

@app_web.route('/')
def home():
    return "I'm alive!"

def run():
    app_web.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()