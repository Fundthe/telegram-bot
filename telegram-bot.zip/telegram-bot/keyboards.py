from telegram import InlineKeyboardButton, InlineKeyboardMarkup

def back_button(state=None, menu=True):
  buttons = [[InlineKeyboardButton("🔙 Назад", callback_data="step_back")]]
  if menu:
      buttons.append([InlineKeyboardButton("📋 Меню", callback_data="back")])
  return InlineKeyboardMarkup(buttons)


def back_to_menu_button():
  return InlineKeyboardMarkup([[InlineKeyboardButton("🔙 В начало", callback_data="back")]])

def wrapper_keyboard(callback_data: str):
  return InlineKeyboardMarkup([
      [InlineKeyboardButton("🚫 Нет", callback_data=callback_data)],
      [InlineKeyboardButton("🔙 Назад", callback_data="step_back"),
       InlineKeyboardButton("📋 Меню", callback_data="back")]
  ])