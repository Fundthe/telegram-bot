import os
import time

from telegram.ext import (
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ConversationHandler,
    filters
)

from config import BOT_TOKEN
from keep_alive import keep_alive

from handlers.menu import start, choose_option
from handlers.states import (
    CHOOSING,
    # 🔁 Лупинг
    LOOP_ADV_STEP1, LOOP_ADV_WRAPPER, LOOP_ADV_BORROW_WRAPPER,
    LOOP_ADV_LTV, LOOP_ADV_LTV_LIQ, LOOP_ADV_RATES, LOOP_ADV_DAYS,

    # 📈 Ставка финансирования
    RATE, HOURS,

    # 💳 Кредитование
    LOAN_DEP_AMOUNT, LOAN_BORROW_AMOUNT, LOAN_LTV, LOAN_THRESHOLD,

    # 💰 Impermanent Loss
    IL_STEP1, IL_STEP2, IL_STEP3, IL_STEP4, IL_STEP5,

    # 📉 PnL
    PNL_ENTRY_PRICE, PNL_EXIT_PRICE, PNL_AMOUNT, PNL_FEE, PNL_POSITION_TYPE,

    # 📊 DCA (новый)
    DCA_ADV_TOKEN, DCA_ADV_COUNT, DCA_ADV_ENTRIES, DCA_ADV_CURRENT, DCA_ADV_RESULT
)

from handlers.funding import get_rate, get_hours

from handlers.dca import (
    handle_dca_token,
    handle_dca_count,
    handle_dca_entries,
    handle_dca_current,
)

from handlers.il import (
    get_il_step1, get_il_step2, get_il_step3,
    get_il_step4, get_il_step5
)

from handlers.loan import (
    get_loan_deposit,
    get_loan_borrow,
    get_loan_ltv,
    get_loan_threshold
)

from handlers.looping import (
    looping_start,
    handle_deposit_and_borrow,
    handle_wrapper_supply,
    handle_wrapper_borrow,
    handle_ltv,
    handle_liq_ltv,
    handle_rates,
    handle_days,
    no_wrapper_callback,
    no_borrow_wrapper_callback,
    back_callback
)
from handlers.il import (
    ask_il_step1,
    get_il_step1, get_il_step2, get_il_step3, get_il_step4, get_il_step5,
    back_callback_il
)
from handlers.pnl import (
    get_pnl_entry, get_pnl_exit, get_pnl_amount, get_pnl_fee,
    pnl_long, pnl_short
)
from handlers.stats import stats_command  # если у тебя есть stats_command


# 📍 Основной обработчик состояний
conv_handler = ConversationHandler(
    entry_points=[
        CommandHandler("start", start),
        CallbackQueryHandler(choose_option, pattern=r"^(looping|dca_mass|rate|loan|il|pnl|back)$")
    ],
    states={
        CHOOSING: [CallbackQueryHandler(choose_option)],

        # 🔁 Лупинг (advanced)
        LOOP_ADV_STEP1: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_deposit_and_borrow),
            CallbackQueryHandler(back_callback, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],
        LOOP_ADV_WRAPPER: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_wrapper_supply),
            CallbackQueryHandler(no_wrapper_callback, pattern="^no_wrapper$"),
            CallbackQueryHandler(back_callback, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],
        LOOP_ADV_BORROW_WRAPPER: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_wrapper_borrow),
            CallbackQueryHandler(no_borrow_wrapper_callback, pattern="^no_borrow_wrapper$"),
            CallbackQueryHandler(back_callback, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],
        LOOP_ADV_LTV: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_ltv),
            CallbackQueryHandler(back_callback, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],
        LOOP_ADV_LTV_LIQ: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_liq_ltv),
            CallbackQueryHandler(back_callback, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],
        LOOP_ADV_RATES: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_rates),
            CallbackQueryHandler(back_callback, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],
        LOOP_ADV_DAYS: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_days),
            CallbackQueryHandler(back_callback, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],

        # 📈 Ставка финансирования
        RATE: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_rate),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        HOURS: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_hours),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],

        # 💳 Кредитование
        LOAN_DEP_AMOUNT: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_loan_deposit),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        LOAN_BORROW_AMOUNT: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_loan_borrow),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        LOAN_LTV: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_loan_ltv),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        LOAN_THRESHOLD: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_loan_threshold),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        
        # 📊 DCA (advanced)
        DCA_ADV_TOKEN: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_dca_token),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        DCA_ADV_COUNT: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_dca_count),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        DCA_ADV_ENTRIES: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_dca_entries),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        DCA_ADV_CURRENT: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, handle_dca_current),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        DCA_ADV_RESULT: [
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back|dca|dca_mass)$")
        ],

        # 💰 Impermanent Loss
        IL_STEP1: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_il_step1),
            CallbackQueryHandler(back_callback_il, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],
        IL_STEP2: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_il_step2),
            CallbackQueryHandler(back_callback_il, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],
        IL_STEP3: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_il_step3),
            CallbackQueryHandler(back_callback_il, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],
        IL_STEP4: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_il_step4),
            CallbackQueryHandler(back_callback_il, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],
        IL_STEP5: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_il_step5),
            CallbackQueryHandler(back_callback_il, pattern="^step_back$"),
            CallbackQueryHandler(choose_option, pattern="^back$")
        ],

        # 📉 PnL
        PNL_ENTRY_PRICE: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_pnl_entry),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        PNL_EXIT_PRICE: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_pnl_exit),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        PNL_AMOUNT: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_pnl_amount),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        PNL_FEE: [
            MessageHandler(filters.TEXT & ~filters.COMMAND, get_pnl_fee),
            CallbackQueryHandler(choose_option, pattern=r"^(step_back|back)$")
        ],
        PNL_POSITION_TYPE: [
            CallbackQueryHandler(choose_option, pattern=r"^(pnl_long|pnl_short|step_back|back)$")
        ]
    },
    fallbacks=[CommandHandler("start", start)]
)


def main():
    if not BOT_TOKEN:
        raise ValueError("❌ Переменная окружения BOT_TOKEN не найдена!")

    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # 🔹 Добавляем основной ConversationHandler
    app.add_handler(conv_handler)

    # 🔹 Команды и кнопки
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("stats", stats_command))
    app.add_handler(CallbackQueryHandler(choose_option))

    # ✅ Правильно: добавляем обработку кнопки "Назад"
    app.add_handler(CallbackQueryHandler(back_callback, pattern="^back$"))

    # 🔹 Обработка ошибок
    async def error_handler(update, context):
        print(f"❌ Ошибка: {context.error}")
        if update:
            print(f"⚠️ Update: {update}")

    app.add_error_handler(error_handler)

    # 🔹 Keep-alive и запуск
    keep_alive()
    app.run_polling()


if __name__ == "__main__":
    main()