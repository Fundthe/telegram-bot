# user_data.py
user_data_temp = {}
last_bot_messages = {}