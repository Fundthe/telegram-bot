from datetime import datetime
from replit import db
from user_data import user_data_temp
from handlers.prompts import STATE_PROMPTS
import re
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from user_data import last_bot_messages

# ✅ Удаление всех сообщений бота по chat_id
import contextlib
async def delete_all_bot_messages(context, chat_id: int):
    messages = last_bot_messages.get(chat_id, [])
    print(f"🧹 Удаляем сообщения: {messages}")
    for msg_id in messages:
        try:
            await context.bot.delete_message(chat_id=chat_id, message_id=msg_id)
        except Exception as e:
            print(f"❌ Ошибка удаления {msg_id}: {e}")
    last_bot_messages[chat_id] = []

# ✅ Универсальный запуск с удалением и сбросом user_data_temp
async def launch_with_cleanup(update, context, chat_id, start_function, module_key=None):
    await delete_all_bot_messages(context, chat_id)

    if module_key:
        user_data_temp[chat_id] = {module_key: {}}
    else:
        user_data_temp[chat_id] = {}

    return await start_function(update, context)
            
# 🔄 Автозамена кириллицы на латиницу
def fix_cyrillic(text):
    repl = {
        "А": "A", "В": "B", "С": "C", "Е": "E", "Н": "H",
        "К": "K", "М": "M", "О": "O", "Р": "P", "Т": "T",
        "Х": "X", "У": "Y", "З": "Z", "И": "I",
    }
    return ''.join(repl.get(c, c) for c in text)

def update_stats(user_id, module=None):
  uid = str(user_id)

  # Обновляем общее количество запусков
  db["total_runs"] = db.get("total_runs", 0) + 1

  # Обновляем по пользователям
  users = db.get("users", {})
  if uid not in users:
      users[uid] = {
          "count": 1,
          "last_used": datetime.now().strftime("%Y-%m-%d")
      }
  else:
      users[uid]["count"] += 1
      users[uid]["last_used"] = datetime.now().strftime("%Y-%m-%d")
  db["users"] = users

  # Обновляем по модулям
  if module:
      modules = db.get("modules", {})
      modules[module] = modules.get(module, 0) + 1
      db["modules"] = modules


def push_state(chat_id, state):
  user_state = user_data_temp.setdefault(chat_id, {})
  history = user_state.setdefault('history', [])
  if not history or history[-1] != state:
      history.append(state)


def pop_prev_state(chat_id):
  user_state = user_data_temp.get(chat_id, {})
  history = user_state.get('history', [])
  if len(history) >= 2:
      history.pop()
      return history[-1]
  return None

def parse_token_input(raw):
  parts = raw.upper().replace(" ", "").split(",")
  result = {}
  for item in parts:
      token, amount, price = item.split("+")
      result[token] = {"amount": float(amount), "price": float(price)}
  return result

def get_prompt_for_state(state):
  return STATE_PROMPTS.get(state, "🔁 Введи значение:")